using UnityEngine;

public class Testdamage : MonoBehaviour
{
    public GameObject bullet;
    public int damage = 10; //The amount of health points the enemy will lose after the bullet triggers the enemies collider


    private void OnTriggerEnter2D(UnityEngine.Collider2D collision) //Collider will trigger the enemyHp script and cause the enemy to lose health
    {
        if (collision.gameObject.TryGetComponent<healthPoints>(out healthPoints enemyDamage))  //Component is another script in the same folder
        {

            enemyDamage.RecieveDamage(damage);
            Debug.Log(collision);
        }
        Destroy(bullet);
    }
    private void OnCollisionEnter2D(UnityEngine.Collision2D collision) //Added on collider2d function because the bullet would not despawn and it would fly through walls,i belive this is because it's collider is set to trigger 
    {
        Destroy(bullet);
    }


}

