using UnityEngine;
using UnityEngine.SceneManagement;
public class MainMenu : MonoBehaviour
{
    public void playGame()
    {
        SceneManager.LoadSceneAsync(1);
        Time.timeScale = 1;
    }
    public void howToPlay()
    {
        SceneManager.LoadSceneAsync(2);
    }
    public void backToMainMenu()
    {
        SceneManager.LoadSceneAsync("Main menu");
    }
    public void quit()
    {
        Application.Quit();
        Debug.Log("RageQuit");
    }
    
       
    
}
