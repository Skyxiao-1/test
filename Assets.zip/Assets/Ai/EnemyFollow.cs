using Unity.VisualScripting;
using UnityEngine;

public class EnemyFollow : MonoBehaviour //Script is for controlling enemy following the player and shooting them
{
  public float speed = 10f;
    private Transform target;
    public float stopDistance;
    public float retreatDistance;

    private float timeBetweenShots;
    public float startTimeBetweenShots = 5f;
    public float bulletForce = 5f;
    public GameObject bullet;
    public Transform firePoint;

    void Start ()
    {
        target= GameObject.FindGameObjectWithTag ("Player").GetComponent<Transform>();

        timeBetweenShots = startTimeBetweenShots;
    }


    void Update()

    {
        if (Vector2.Distance(transform.position, target.position) > stopDistance)
        {
            transform.position = Vector2.MoveTowards(transform.position, target.position, speed * Time.deltaTime);
        }
        else if (Vector2.Distance(transform.position, target.position) < stopDistance && (Vector2.Distance(transform.position, target.position) > retreatDistance))
        {
            transform.position = this.transform.position;
        }
        else if (Vector2.Distance(transform.position, target.position) < retreatDistance)
        {
            transform.position = Vector2.MoveTowards(transform.position, target.position, -speed * Time.deltaTime);
        }
        if (timeBetweenShots <= 0)
        { timeBetweenShots = startTimeBetweenShots;

           Instantiate(bullet, transform.position,Quaternion.identity);
            timeBetweenShots = startTimeBetweenShots;
           
        }
        else { timeBetweenShots -= Time.deltaTime; }
    }
    
   
}
