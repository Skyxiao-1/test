using JetBrains.Annotations;
using System.Collections;
using System.Runtime.CompilerServices;
using Unity.VisualScripting;
using UnityEngine;

public class Ultron : MonoBehaviour
{

    //enemy detection 
    [Range(1, 20)]
    [SerializeField]
    private float viewRadius = 11;
    [SerializeField]
    private float detectionCheckDelay = 0.1f;
    [SerializeField]
    private Transform target = null;
    [SerializeField]
    private LayerMask playerLayerMask;
    [SerializeField]
    private LayerMask visibilityLayer;


    [field:SerializeField]
    public bool TargetVisible { get; private set; }
   
   

     void Start()
    {  
       
        StartCoroutine(DetectionCoroutine());
        
        target = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
    }

     
    public Transform Target
    {
        get => target;
        set
        {
            target = value;
            TargetVisible = false;
        }
        
    }
   
        private void detectTarget()
    {
        if (Target == null)
            CheckIfPlayerInRange();
        
        else if (Target != null)
            DetectIfOutOfRange();
    }
    private void DetectIfOutOfRange()
    {
        if (Target == null || Target.gameObject.activeSelf == false || Vector2.Distance(transform.position, Target.position) > viewRadius)
        {
            target = null;
        }
    }
    private void CheckIfPlayerInRange()
    {
        Collider2D collsion = Physics2D.OverlapCircle(transform.position, viewRadius, playerLayerMask);
        if (collsion != null)
        {
            Target = collsion.transform;
           
        }
    }
    IEnumerator DetectionCoroutine()
    {
        yield return new WaitForSeconds(detectionCheckDelay);
        detectTarget();
        StartCoroutine(DetectionCoroutine());
    }

   
      
    
    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(transform.position , viewRadius);
    }
}

  
    
