//SHOOTING/FOLLOW/RETREAT ENEMY AI WITH UNITY AND C# - EASY TUTORIAL
//BlackThornProd
//Accessed 26 March 2025
// Version 3
//https://youtu.be/_Z1t7MNk0c4?si=_U_USD_mNGJlWhPr
using UnityEngine;

public class NewMonoBehaviourScript : MonoBehaviour //This is the script that controls the projectile that the enemy is supposed to shoot Ai amd state machines might take time to figure out so this script might not be implemented
{

    [SerializeField]
    private GameObject bulletPre;
    public float speed = 10f;
    private Transform player;
    private Vector2 target;
   
     void Start() //Finding the players position in the game 
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        target = new Vector2(player.position.x, player.position.y);

    }
     void Update() //The projectile will be launched and will travel to the position where the player is/was at the time the bullet was shot by the enemy and when the bullet misses the bullet will despawn when it reaches its location
    {
      
        
        transform.position = Vector2.MoveTowards(transform.position, target, speed * Time.deltaTime);
        
        if (transform.position.x == target.x && transform.position.y == target.y)
        {
          
            DestroyProjectile();
        }
      void DestroyProjectile()
        {
            Destroy(bulletPre);
            Debug.Log("He missed");
        }

    }
    private void OnTriggerEnter2D(Collider2D collision) //When the bullet hits the player the projectile will despwn immeditaley and the player will recieve damage  
    {
        if (collision.CompareTag("Player"))
            {
            Destroy(bulletPre);
        }


        }

        
                 
         
    }
   

