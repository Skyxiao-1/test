//How To DAMAGE Enemies in Unity
//BMo
//Accessed 20 March 2025
//Version 2
//https://youtu.be/anHxFtiVuiE?si=SiLtQANzkFOzqH29
using UnityEngine;

public class enemyHp : MonoBehaviour
{
    public int maxHeatlh = 100;
    public int currentHealth = 0;
   
    void Start()
    { 
        currentHealth = maxHeatlh; 
    }

    public void TakeDamage(int damage)  //This method is called in the HitDetection script when bullet collides with the enemies collider 
    {
        currentHealth -= damage;
        if (currentHealth <= 0)
        {

            Die();
        }

        void Die()
        {
            Destroy(gameObject);
            //Death animation,item drops and all related elements will go here.

        }
    }
}
