//TOP DOWN SHOOTING in Unity
//Brackeys
// Accessed 19 March 2025
// Version 2 
//https://youtu.be/LNLVOjbrQj4?si=m_YMRHaFrIl__yZU
using UnityEngine;
using UnityEngine.XR;

public class Shooting : MonoBehaviour
{
    public Transform firePoint; //The place of spawning the bullet
    public GameObject bulletPrefab; 

    public float bulletForce = 10f; //Force at which the bullets rigidbody will be applied to

   
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0)==true)
        {
            shoot(); //New Method because Unity does not have a built in method for shooting
        }
    }
      void shoot()
    {
       GameObject bullet= Instantiate(bulletPrefab,firePoint.position,firePoint.rotation);
        Rigidbody2D rb = bullet.GetComponent<Rigidbody2D>();
        rb.AddForce (firePoint.up  * bulletForce , ForceMode2D.Impulse); 
    }

     
}
