//TOP DOWN SHOOTING in Unity
//Brackeys
// Accessed 19 March 2025
// Version 3
//https://youtu.be/LNLVOjbrQj4?si=m_YMRHaFrIl__yZU

using UnityEngine;
using UnityEngine.Rendering;

public class HitDetection : MonoBehaviour
{
    public GameObject bullet;
    public int damage = 10; //The amount of health points the enemy will lose after the bullet triggers the enemies collider
    

    private void OnTriggerEnter2D(UnityEngine.Collider2D collision) //Collider will trigger the enemyHp script and cause the enemy to lose health
    {
         if (collision.gameObject.TryGetComponent <enemyHp>(out enemyHp enemyDamage ))  //Component is another script in the same folder
        {

            enemyDamage.TakeDamage(damage); 
            Debug.Log(collision);
        }
        Destroy(bullet);
    }
    private void OnCollisionEnter2D(UnityEngine.Collision2D collision) //Added on collider2d function because the bullet would not despawn and it would fly through walls,i belive this is because it's collider is set to trigger 
    {
        Destroy(bullet);
    }  

        
    }


